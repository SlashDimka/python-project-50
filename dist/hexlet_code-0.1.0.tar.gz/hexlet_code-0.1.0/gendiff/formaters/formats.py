JSON = 'json'
STYLISH = 'stylish'
PLAIN = 'plain'
