### make lint
[![linter](https://github.com/SlashDimka/python-project-50/actions/workflows/make-lint.yml/badge.svg)](https://github.com/SlashDimka/python-project-50/actions/workflows/make-lint.yml)
### Hexlet tests and linter status:
[![Test Coverage](https://api.codeclimate.com/v1/badges/f06ecbbd4cc7d887d05d/test_coverage)](https://codeclimate.com/github/SlashDimka/python-project-50/test_coverage)
[![Maintainability](https://api.codeclimate.com/v1/badges/f06ecbbd4cc7d887d05d/maintainability)](https://codeclimate.com/github/SlashDimka/python-project-50/maintainability)
[![Actions Status](https://github.com/SlashDimka/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/SlashDimka/python-project-50/actions)
[![asciicast](https://asciinema.org/a/2YZuOGtMNrZ386aUf8UJbJMXM.svg)](https://asciinema.org/a/2YZuOGtMNrZ386aUf8UJbJMXM)
