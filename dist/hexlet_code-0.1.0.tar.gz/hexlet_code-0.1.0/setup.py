# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.formaters', 'gendiff.scripts']

package_data = \
{'': ['*']}

install_requires = \
['PyYAML>=6.0,<7.0']

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendiff:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'show difference between two data files',
    'long_description': '### make lint\n[![linter](https://github.com/SlashDimka/python-project-50/actions/workflows/make-lint.yml/badge.svg)](https://github.com/SlashDimka/python-project-50/actions/workflows/make-lint.yml)\n### Hexlet tests and linter status:\n[![Test Coverage](https://api.codeclimate.com/v1/badges/f06ecbbd4cc7d887d05d/test_coverage)](https://codeclimate.com/github/SlashDimka/python-project-50/test_coverage)\n[![Maintainability](https://api.codeclimate.com/v1/badges/f06ecbbd4cc7d887d05d/maintainability)](https://codeclimate.com/github/SlashDimka/python-project-50/maintainability)\n[![Actions Status](https://github.com/SlashDimka/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/SlashDimka/python-project-50/actions)\n[![asciicast](https://asciinema.org/a/2YZuOGtMNrZ386aUf8UJbJMXM.svg)](https://asciinema.org/a/2YZuOGtMNrZ386aUf8UJbJMXM)\n',
    'author': 'SlashDimka',
    'author_email': 'korolkovpro@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
