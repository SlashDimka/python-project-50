import json


def display_diff(diff):
    return json.dumps(diff)
